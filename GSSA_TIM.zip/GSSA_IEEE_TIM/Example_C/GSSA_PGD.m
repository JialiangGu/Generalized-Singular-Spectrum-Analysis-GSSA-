function [W,corr] = GSSA_PGD(x,T,L,Fs,N,Num)

% Input:
%       x:     N*1 signal
%       T:     maximum iteration 
%       L:     embedding dimension
%       Fs:    sampling frequency
%       N:     length of the signal
%       Num:   number of SSA components for signal reconstruction
%
% Output:
%       W:              taper windows
%       corr:           correlation between reconstructed modes

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% cosine matrix
for m=0:N-1
    for n=0:2:L-1
        cosine1(m+1,round(n/2)+1) = cos((pi*m*(L-1-n)/N));
    end
end
for m=0:N-1
    for n=2:L-1
        cosine2(m+1,round(n/2)) = cos((pi*m*n/N));
    end
end
cosine = [cosine1 cosine2]/sqrt(N);
%----------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% parameter setting
epsilon1 = 0.0001; epsilon2 = 0.05; % coefficients range
gamma_w = 0.0001; gamma_delta = 0.005; % step size for gradient descent
threshold = -0.0001; % stopping criterion for alternation
W(:,1) = ones(L,1) ./ L; % window initialization
Delta = zeros(N,T+1); % delta initilization
% alpha
[ssa_vector0,U0, Y0, S0] = gssa(x,ones(L,1));
alpha = L*sum(diag(U0'* diag(W(:,1)) *S0* diag(W(:,1)) *U0))/sum(abs(sum(cosine,2)));
% beta
gamma = 0.2;
beta = 1./((1:N).^(gamma));
beta(1,N/2+1:end) = fliplr(beta(1:N/2));
%-------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Alternating Optimization
for t = 1:T
    t
    %----------------------------------------- P1, update U
    [ssa_vector, U, Y, S] = gssa(x,W(:,t));
    
    % select components for reconstruction
    correlation = abs(ssa_vector*ssa_vector');
    corr(t, 1) = (sum(sum(correlation(1:Num,1:Num)))-Num)/(Num*(Num-1));% calculate the average correlation coefficients
    
    % stopping criterion for AO
    if (t > 2)
        if ((t == T) | (corr(t,1) - corr(t-1,1) > threshold))
            % reconstruction
            [ssa_vector_opt, U_opt, Y_opt, S_opt] = gssa(x,W(:,t-1)); % select window at t-1 iteration
            break;
        end
    end
    
    % Otherwise, solve P2, GSSA components selected for reconstruction 
    A = zeros(L,L);
    for i = 1:Num
        A = A + diag(U(:,i))*S0*diag(U(:,i)); 
    end
   
    % gradient descent
    w_gradient(:,t) = (A + A') * W(:,t); % w gradient, note that A may not be symmetric
    delta_gradient(:,t) = alpha * beta'; % delta gradient
    w0 = W(:,t) + gamma_w * w_gradient(:,t);
    delta0 = Delta(:,t) - gamma_delta * delta_gradient(:,t);
    
    % quadprog
    H = 2*[-A zeros(L,N);zeros(N,L) zeros(N,N)];
    f = [zeros(1,L) beta];
    S = [eye((L-1)/2) zeros((L-1)/2,1) fliplr(-eye((L-1)/2)) zeros((L-1)/2,N)]; % symmetric
    A_ineq1 = [(eye((L-1)/2) + diag(-ones((L-3)/2,1),1)) [zeros((L-3)/2,1);-1] zeros((L-1)/2,(L-1)/2+N)];% increasing
    A_ineq2 = [cosine diag(-ones(N,1));-cosine diag(-ones(N,1))];% L1 norm relaxation
    A_ineq3 = [(eye((L-3)/2) + diag(-ones((L-5)/2,1),1)) [zeros((L-5)/2,1);-1]]; %concave
    %A_ineq = [A_ineq2;A_ineq1;(A_ineq3*A_ineq1)];
    A_ineq = [A_ineq2;A_ineq1];
    %b = zeros(2*N+(L-1)/2+(L-3)/2,1);
    b = zeros(2*N+(L-1)/2,1);
    Aeq1 = [ones(1,L) zeros(1,N)];
    Aeq = [Aeq1;S];
    beq = [1;zeros((L-1)/2,1)];
    lb = [epsilon1*ones(L,1);zeros(N,1)];
    ub = [epsilon2*ones(L,1);ones(N,1)./sqrt(N)];
    
    % projection
    w = [w0;delta0];
    [w_hat,fval]=quadprog(eye(L+N),-2*w',A_ineq,b,Aeq,beq,lb,ub,[]);% meet the constraints
    W(:,t+1) = w_hat(1:L);
    Delta(:,t+1) = w_hat(L+1:end);
    Minimum(t+1,1) = -W(:,t+1)'*A*W(:,t+1) + alpha*beta*Delta(:,t+1);
    
end

end

