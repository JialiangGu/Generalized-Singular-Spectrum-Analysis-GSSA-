function [xf,U,Y,S] = L1_SSA(x, L)

% -----------------------------------embedding
N=length(x);
K = N - L + 1;
X=zeros(L,K);
w = zeros(L,1);  % weights
b = zeros(L*K, 1); % linear programming: introduced variables
for k=1:size(x)-L+1
    X(:,k)=x(k:k+L-1,1); % trajectory matrix
end


% -------------------------------decomposition
S = X * transpose(X);
[Upi,Lemda] = eig(S);
lemda=diag(Lemda);
[Y,I]=sort(lemda,'descend');
for k=1:length(Y),
    if lemda(I(k))>0,
        U(:,k)=Upi(:,I(k));
    end;
end;
D=size(U,2);

for k=1:D 
    V1(:,k)=X'*U(:,k)/sqrt(lemda(k));   
    Xpi(:,:,k)=sqrt(lemda(k))*U(:,k)*V1(:,k)';

    
    % L1 deHanelization
    xf(k,:) = L1_Hankelization(Xpi(:,:,k), L, K);   
    
end

end


function [Frec] = L1_Hankelization(Xp, L, K)

Xp_fli = fliplr(Xp); 
for k = -(L-1):K-1
    d = [];
    d = diag(Xp_fli,k);  % anti-diagonal elements
    %Frec(1,L+k) = mean(d); % conventional averaging method
    Frec(1,L+k) = median(d); % median method : L1 SSA
    
end

Frec = fliplr(Frec);
    

end
