function [xf, Upi, Y, S] = gssa(x,w)

% Input:
%       x: N*1 signal
%       w: L*1 window function
%
% Output:
%       xf:  SSA components
%       Upi: Eigenvectors, i.e., FIR filters
%       Y:   Eigenvalues
%       S:   Co-variance matrix of the signal

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

L=length(w);
N=length(x);
K=N-L+1;
X=zeros(L,K);

for k=1:K
    X(:,k)=w.*x(k:k+L-1,1); % use taper window w for signal truncation
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SVD
S = (X * transpose(X));
[U,Lemda] = eig(S);
lemda=diag(Lemda);
[Y,I]=sort(lemda,'descend');
for k=1:length(Y),
    if lemda(I(k))>0,
        Upi(:,k)=U(:,I(k));
    end;
end;
D=size(Upi,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% reconstruction
for k=1:D 
    V1(:,k)=transpose(X)*Upi(:,k)/sqrt(lemda(k));   
    Xpi(k,:,:)=sqrt(lemda(k))*Upi(:,k)*transpose(V1(:,k));
end
for d=1:D
    Xtutor=zeros(L,K);
    for k=1:K
        Xtutor(:,k)=Xpi(d,:,k);
    end

    % anti-diagonal averaging method with taper window w
    xf(d,:)=GenHankelization(Xtutor,L,K,N,w); 
   
end

end

function Frec=GenHankelization(Y,L,K,N,w)

% rank-1 matrix production
for k=1:N-L+1
    W(:,k)=w;
end

for k=1:L
    d=0;
    d1=0;
    for m=1:k
        d=d+Y(m,k-m+1);
        d1=d1+W(m,k-m+1);
    end
    Frec(k)=d/d1;
end
for k=L+1:K-1
    d=0;
    d1=0;
    for m=1:L
        d=d+Y(m,k-m+1);
        d1=d1+W(m,k-m+1);
%         disp(d1);
    end
    Frec(k)=d/d1;
end
for k=K:N
    d=0;
    d1=0;
    for m=k-K+1:L
        d=d+Y(m,k-m+1);
        d1=d1+W(m,k-m+1);
    end
    Frec(k)=d/d1;
end

end

