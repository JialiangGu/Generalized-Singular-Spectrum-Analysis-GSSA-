clear;
clc;
close all;

L=101; % embedding dimension

% loading data
load('data.mat')
N = length(x); % signal length
Fs = 174;

%------------------------------------------------benchmark strategies
[ssa_vector0,U0, Y0, S0] = gssa(x,ones(L,1));
[ssa_vector_L1,U_L1, Y_L1, S_L1] = L1_SSA(x, L);
[ssa_vector_PCA_L1,U_PCA_L1,X] = PCA_L1_greedy(x, L);

%  GSSA
T = 10; % maximum iteration for AO
Num = 5; % number of SSA components for reconstruction; 5-20
[W,corr] = GSSA_PGD(x,T,L,Fs,N,Num); 
%---------------------------------------------
    
[ssa_vector_opt, U_opt, Y_opt, S_opt] = gssa(x,W(:,end-1)); % select window at t-1 iteration
            

%-----------------------------------------figure 7
Nfft = N;
time=(1:N)/Fs;
figure;
plot(time,x,'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 24 -1 1]);
xticks([0 6 12 18 24]);%yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
figure;
fft_x = ((abs(fft(x,Nfft))));
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xticks([0 20 40 60 80]);%yticks([-1 0 1])
set(gca, 'FontSize', 15)
grid on
figure;
plot(time,ssa_vector_opt(1,:),'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 24 -0.3 0.3]);
xticks([0 6 12 18 24]);yticks([-0.3 0 0.3])
grid on
set(gca, 'FontSize', 15)
figure;
fft_x = ((abs(fft(ssa_vector_opt(1,:),Nfft))));
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xticks([0 20 40 60 80]);%yticks([-0.2 0 0.2])
set(gca, 'FontSize', 15)
grid on
figure;
plot(time,ssa_vector_opt(2,:),'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 24 -0.2 0.2]);
xticks([0 6 12 18 24]);yticks([-0.2 0 0.2])
grid on
set(gca, 'FontSize', 15)
figure;
fft_x = ((abs(fft(ssa_vector_opt(2,:),Nfft))));
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xticks([0 20 40 60 80]);%yticks([-0.2 0 0.2])
set(gca, 'FontSize', 15)
grid on
figure;
plot(time,ssa_vector_opt(3,:),'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 24 -0.2 0.2]);
xticks([0 6 12 18 24]);yticks([-0.2 0 0.2])
grid on
set(gca, 'FontSize', 15)
figure;
fft_x = ((abs(fft(ssa_vector_opt(3,:),Nfft))));
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xticks([0 20 40 60 80]);%yticks([-0.2 0 0.2])
set(gca, 'FontSize', 15)
grid on
figure;
plot(time,ssa_vector_opt(4,:),'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 24 -0.2 0.2]);
xticks([0 6 12 18 24]);yticks([-0.2 0 0.2])
grid on
set(gca, 'FontSize', 15)
figure;
fft_x = ((abs(fft(ssa_vector_opt(4,:),Nfft))));
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xticks([0 20 40 60 80]);%yticks([-0.2 0 0.2])
set(gca, 'FontSize', 15)
grid on
figure;
plot(time,ssa_vector_opt(5,:),'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 24 -0.1 0.1]);
xticks([0 6 12 18 24]);yticks([-0.1 0 0.1])
grid on
set(gca, 'FontSize', 15)
figure;
fft_x = ((abs(fft(ssa_vector_opt(5,:),Nfft))));
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xticks([0 20 40 60 80]);%yticks([-0.2 0 0.2])
set(gca, 'FontSize', 15)
grid on


%------------------------------------ figure 8
% GSSA
Nfft = N;
figure()
subplot(2,1,1)
hold on
c1 = sum(ssa_vector_opt([1 2 5],:));
fft1=((abs(fft(c1,Nfft))))/sqrt(Nfft);
plot(Fs/Nfft:Fs/Nfft:Fs/2,fft1(1:Nfft/2), 'b','linewidth', 1.5)
plot(0.5*ones(3),[0:2],'m--','LineWidth',1)
plot(4*ones(3),[0:2],'m--','LineWidth',1)
xlim([0 25])
ylabel('Magnitude')
%title('Delta rhythm')
set(gca, 'FontSize', 18)
grid on
subplot(2,1,2)
hold on
c2 = sum(ssa_vector_opt([3 4],:));
fft2=((abs(fft(c2,Nfft))))/sqrt(Nfft);
plot(Fs/Nfft:Fs/Nfft:Fs/2,fft2(1:Nfft/2), 'b','linewidth', 1.5)
plot(9*ones(3),[0:2],'m--','LineWidth',1)
plot(13*ones(3),[0:2],'m--','LineWidth',1)
xlim([0 25])
yticks([0 1])
xlabel('Frequency (Hz)')
ylabel('Magnitude')
%title('Alpha rhythm')
grid on
set(gca, 'FontSize', 18)
delta1=fft1(round(0.5*Nfft/Fs):round(4*Nfft/Fs));
delta2=fft1(round(8*Nfft/Fs):round(13*Nfft/Fs));
ratio_delta=(delta1*delta1')/(fft1(1:Nfft/2)*fft1(1:Nfft/2)')
alpha1=fft2(round(0.5*Nfft/Fs):round(4*Nfft/Fs));
alpha2=fft2(round(8*Nfft/Fs):round(13*Nfft/Fs));
ratio_alpha=(alpha2*alpha2')/(fft2(1:Nfft/2)*fft2(1:Nfft/2)')

% basic SSA
figure()
subplot(2,1,1)
hold on
c1 = sum(ssa_vector0([1 2 5 8],:));
fft1=((abs(fft(c1,Nfft))))/sqrt(Nfft);
plot(Fs/Nfft:Fs/Nfft:Fs/2,fft1(1:Nfft/2), 'b','linewidth', 1.5)
plot(0.5*ones(3),[0:2],'m--','LineWidth',1)
plot(4*ones(3),[0:2],'m--','LineWidth',1)
xlim([0 25])
ylabel('Magnitude')
%title('Delta rhythm')
set(gca, 'FontSize', 18)
grid on
subplot(2,1,2)
hold on
c2 = sum(ssa_vector0([3 4 6 7],:));
fft2=((abs(fft(c2,Nfft))))/sqrt(Nfft);
plot(Fs/Nfft:Fs/Nfft:Fs/2,fft2(1:Nfft/2), 'b','linewidth', 1.5)
plot(9*ones(3),[0:2],'m--','LineWidth',1)
plot(13*ones(3),[0:2],'m--','LineWidth',1)
xlim([0 25])
yticks([0 1])
xlabel('Frequency (Hz)')
ylabel('Magnitude')
%title('Alpha rhythm')
grid on
set(gca, 'FontSize', 18)
delta1=fft1(round(0.5*Nfft/Fs):round(4*Nfft/Fs));
delta2=fft1(round(8*Nfft/Fs):round(13*Nfft/Fs));
ratio_delta=(delta1*delta1')/(fft1(1:Nfft/2)*fft1(1:Nfft/2)')
alpha1=fft2(round(0.5*Nfft/Fs):round(4*Nfft/Fs));
alpha2=fft2(round(8*Nfft/Fs):round(13*Nfft/Fs));
ratio_alpha=(alpha2*alpha2')/(fft2(1:Nfft/2)*fft2(1:Nfft/2)')

% L1 SSA
figure()
subplot(2,1,1)
hold on
c1 = sum(ssa_vector_L1([1 2 5 8],:));
fft1=((abs(fft(c1,Nfft))))/sqrt(Nfft);
plot(Fs/Nfft:Fs/Nfft:Fs/2,fft1(1:Nfft/2), 'b','linewidth', 1.5)
plot(0.5*ones(3),[0:2],'m--','LineWidth',1)
plot(4*ones(3),[0:2],'m--','LineWidth',1)
xlim([0 25])
ylabel('Magnitude')
%title('Delta rhythm')
set(gca, 'FontSize', 18)
grid on
subplot(2,1,2)
hold on
c2 = sum(ssa_vector_L1([3 4 6 7],:));
fft2=((abs(fft(c2,Nfft))))/sqrt(Nfft);
plot(Fs/Nfft:Fs/Nfft:Fs/2,fft2(1:Nfft/2), 'b','linewidth', 1.5)
plot(9*ones(3),[0:2],'m--','LineWidth',1)
plot(13*ones(3),[0:2],'m--','LineWidth',1)
xlim([0 25])
yticks([0 1])
xlabel('Frequency (Hz)')
ylabel('Magnitude')
%title('Alpha rhythm')
grid on
set(gca, 'FontSize', 18)
delta1=fft1(round(0.5*Nfft/Fs):round(4*Nfft/Fs));
delta2=fft1(round(8*Nfft/Fs):round(13*Nfft/Fs));
ratio_delta=(delta1*delta1')/(fft1(1:Nfft/2)*fft1(1:Nfft/2)')
alpha1=fft2(round(0.5*Nfft/Fs):round(4*Nfft/Fs));
alpha2=fft2(round(8*Nfft/Fs):round(13*Nfft/Fs));
ratio_alpha=(alpha2*alpha2')/(fft2(1:Nfft/2)*fft2(1:Nfft/2)')

% PCA L1 SSA
Nfft = N;
figure()
subplot(2,1,1)
hold on
c1 = sum(ssa_vector_PCA_L1([1 2 5 8],:));
fft1=((abs(fft(c1,Nfft))))/sqrt(Nfft);
plot(Fs/Nfft:Fs/Nfft:Fs/2,fft1(1:Nfft/2), 'b','linewidth', 1.5)
plot(0.5*ones(3),[0:2],'m--','LineWidth',1)
plot(4*ones(3),[0:2],'m--','LineWidth',1)
xlim([0 25])
ylabel('Magnitude')
%title('Delta rhythm')
set(gca, 'FontSize', 18)
grid on
subplot(2,1,2)
hold on
c2 = sum(ssa_vector_PCA_L1([3 4 6 7],:));
fft2=((abs(fft(c2,Nfft))))/sqrt(Nfft);
plot(Fs/Nfft:Fs/Nfft:Fs/2,fft2(1:Nfft/2), 'b','linewidth', 1.5)
plot(9*ones(3),[0:2],'m--','LineWidth',1)
plot(13*ones(3),[0:2],'m--','LineWidth',1)
xlim([0 25])
yticks([0 1])
xlabel('Frequency (Hz)')
ylabel('Magnitude')
%title('Alpha rhythm')
grid on
set(gca, 'FontSize', 18)
delta1=fft1(round(0.5*Nfft/Fs):round(4*Nfft/Fs));
delta2=fft1(round(8*Nfft/Fs):round(13*Nfft/Fs));
ratio_delta=(delta1*delta1')/(fft1(1:Nfft/2)*fft1(1:Nfft/2)')
alpha1=fft2(round(0.5*Nfft/Fs):round(4*Nfft/Fs));
alpha2=fft2(round(8*Nfft/Fs):round(13*Nfft/Fs));
ratio_alpha=(alpha2*alpha2')/(fft2(1:Nfft/2)*fft2(1:Nfft/2)')
