function [xf,W,X] = PCA_L1_greedy(x, L)

% Principal Component Analysis Based on L1-Norm Maximization. TPAMI, 2008.

N=length(x);
K = N - L + 1;
X=zeros(L,K);
for k=1:size(x)-L+1
    X(:,k)=x(k:k+L-1,1); % trajectory matrix
end


% -------------------------------decomposition
S = X * transpose(X);
[Upi,Lemda] = eig(S);
lemda=diag(Lemda);
[Y,I]=sort(lemda,'descend');
for k=1:length(Y),
    if lemda(I(k))>0,
        U(:,k)=Upi(:,I(k));
    end;
end;
D=size(U,2);

% initilization
%W = zeros(L,L);
Y = X;

for d = 1:D
    w_rand = rand(L,1);
    W(:,d) = w_rand / norm(w_rand,2);

    condition = 1;
    while condition > 0

        p = ones(K,1);
        v = W(:,d)'*Y; % p indicator
        while length(find(v == 0)) > 0
            delta_w = 0.0001*rand(L,1);
            W(:,d) = (W(:,d)+delta_w)/norm(W(:,d)+delta_w,2);
            v = W(:,d)'*Y; % p indicator
        end

        p(find(v < 0)) = -1;
        
        w = (Y * p) / norm(Y * p, 2); % update w
        if w - W(:,d)==0
            condition = 0;
        end
        W(:,d) = w; % update pojection direction
    end

    Y = Y - W(:,d)*W(:,d)'*Y;

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

V_T = W'*X;  
for k=1:D % D意思等价于特征值不为零的个数
    Xpi(:,:,k)=W(:,k)*V_T(k,:);%Xpi(i,:,:)代表一个分量即Xpi所有矩阵的第i行，就是第i个分量的所有列

    % L1 deHanelization
    %xf(k,:) = L1_Hankelization(Xpi(:,:,k), L, K);  
    
    % L2 dehankelization
    re=GenHankelization(Xpi(:,:,k),L,K,N,ones(L,1));
    xf(k,:)= re(1,:);
end

end

function Frec=GenHankelization(Y,L,K,N,w)

% rank-1 matrix production
for k=1:N-L+1
    W(:,k)=w;
end

for k=1:L
    d=0;
    d1=0;
    for m=1:k
        d=d+Y(m,k-m+1);
        d1=d1+W(m,k-m+1);
    end
    Frec(k)=d/d1;
end
for k=L+1:K-1
    d=0;
    d1=0;
    for m=1:L
        d=d+Y(m,k-m+1);
        d1=d1+W(m,k-m+1);
%         disp(d1);
    end
    Frec(k)=d/d1;
end
for k=K:N
    d=0;
    d1=0;
    for m=k-K+1:L
        d=d+Y(m,k-m+1);
        d1=d1+W(m,k-m+1);
    end
    Frec(k)=d/d1;
end

end


