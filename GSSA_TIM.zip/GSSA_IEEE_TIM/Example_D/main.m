clear;
clc;
close all;

L=151; % embedding dimension

% loading running data
load('running_data.mat')
Fs = 128;
x = an(1:end-1);
N = length(x);

%----------------------------------------------------benchmark strategies
[ssa_vector0,U0, Y0, S0] = gssa(x,ones(L,1));
[ssa_vector_L1,U_L1, Y_L1, S_L1] = L1_SSA(x, L);
[ssa_vector_PCA_L1,U_PCA_L1,X] = PCA_L1_greedy(x, L);

%  GSSA
T = 5; % maximum iteration for AO
Num = 10;
[W,corr] = GSSA_PGD(x,T,L,Fs,N,Num); 
    

[ssa_vector_opt, U_opt, Y_opt, S_opt] = gssa(x,W(:,end-1)); % select window at t-1 iteration


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure 9
Nfft = N;
time=(1:N)/Fs;
figure;
plot(time,x,'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 51 -50 50]);
xticks([0 10 20 30 40 50]);%yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
figure;
fft_x = ((abs(fft(x,Nfft))))/sqrt(Nfft);
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xlim([0 8])
xticks([0 2 4 6 8]);%yticks([-1 0 1])
set(gca, 'FontSize', 15)
grid on
figure;
plot(time,ssa_vector_opt(1,:),'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 51 -20 20]);
xticks([0 10 20 30 40 50]);%yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
figure;
fft_x = ((abs(fft(ssa_vector_opt(1,:),Nfft))))/sqrt(Nfft);
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xlim([0 8])
xticks([0 2 4 6 8]);%yticks([-1 0 1])
set(gca, 'FontSize', 15)
grid on
figure;
plot(time,ssa_vector_opt(2,:),'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 51 -20 20]);
xticks([0 10 20 30 40 50]);%yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
figure;
fft_x = ((abs(fft(ssa_vector_opt(2,:),Nfft))))/sqrt(Nfft);
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xlim([0 8])
xticks([0 2 4 6 8]);%yticks([-1 0 1])
set(gca, 'FontSize', 15)
grid on
figure;
plot(time,ssa_vector_opt(3,:),'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 51 -20 20]);
xticks([0 10 20 30 40 50]);%yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
figure;
fft_x = ((abs(fft(ssa_vector_opt(3,:),Nfft))))/sqrt(Nfft);
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xlim([0 8])
xticks([0 2 4 6 8]);%yticks([-1 0 1])
set(gca, 'FontSize', 15)
grid on
figure;
plot(time,ssa_vector_opt(4,:),'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 51 -20 20]);
xticks([0 10 20 30 40 50]);%yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
figure;
fft_x = ((abs(fft(ssa_vector_opt(4,:),Nfft))))/sqrt(Nfft);
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xlim([0 8])
xticks([0 2 4 6 8]);%yticks([-1 0 1])
set(gca, 'FontSize', 15)
grid on
figure;
plot(time,ssa_vector_opt(5,:),'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 51 -20 20]);
xticks([0 10 20 30 40 50]);%yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
figure;
fft_x = ((abs(fft(ssa_vector_opt(5,:),Nfft))))/sqrt(Nfft);
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xlim([0 8])
xticks([0 2 4 6 8]);%yticks([-1 0 1])
set(gca, 'FontSize', 15)
grid on


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  figure 10
% GSSA
figure()
subplot(2,1,1)
plot(time,sum(ssa_vector_opt([1 2],:)),'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 51 -30 30]);
xticks([0 10 20 30 40 50]);%yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
grid on
subplot(2,1,2)
fft_x = ((abs(fft(sum(ssa_vector_opt([1 2],:)),Nfft))))/sqrt(Nfft);
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xlim([0 8])
xticks([0 2 4 6 8]);%yticks([-1 0 1])
set(gca, 'FontSize', 15)
grid on


% basic SSA
figure()
subplot(2,1,1)
plot(time,sum(ssa_vector0([1 2],:)),'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 51 -30 30]);
xticks([0 10 20 30 40 50]);%yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
grid on
subplot(2,1,2)
fft_x = ((abs(fft(sum(ssa_vector0([1 2],:)),Nfft))))/sqrt(Nfft);
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xlim([0 8])
xticks([0 2 4 6 8]);%yticks([-1 0 1])
set(gca, 'FontSize', 15)
grid on

% L1 SSA
figure()
subplot(2,1,1)
plot(time,sum(ssa_vector_L1([1 2],:)),'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 51 -30 30]);
xticks([0 10 20 30 40 50]);%yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
grid on
subplot(2,1,2)
fft_x = ((abs(fft(sum(ssa_vector_L1([1 2],:)),Nfft))))/sqrt(Nfft);
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xlim([0 8])
xticks([0 2 4 6 8]);%yticks([-1 0 1])
set(gca, 'FontSize', 15)
grid on

% PCA L1 SSA
figure()
subplot(2,1,1)
plot(time,sum(ssa_vector_PCA_L1([1 2],:)),'b-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 51 -30 30]);
xticks([0 10 20 30 40 50]);%yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
subplot(2,1,2)
fft_x = ((abs(fft(sum(ssa_vector_PCA_L1([1 2],:)),Nfft))))/sqrt(Nfft);
plot([Fs/Nfft:Fs/Nfft:Fs/2], fft_x(1:Nfft/2), 'b')
xlabel('Frequency (Hz)')
ylabel('Magnitude')
xlim([0 8])
xticks([0 2 4 6 8])
set(gca, 'FontSize', 15)
grid on


figure()
hold on
plot(time,sum(ssa_vector_opt([1 2],:)),'b-','linewidth',1.2)
plot(time,sum(ssa_vector0([1 2],:)),'r-','linewidth',1.2)
plot(time,sum(ssa_vector_L1([1 2],:)),'k-','linewidth',1.2)
xlabel('Time');ylabel('Amplitude');axis ([0 51 -30 30]);
xticks([0 10 20 30 40 50])
legend('GSSA PGD-AO', 'L2-norm maximization', 'L1-norm hankelization')
grid on
set(gca, 'FontSize', 15)
