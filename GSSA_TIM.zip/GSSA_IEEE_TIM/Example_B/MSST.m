function [Ts1_sig, Ts1_6_sig,Ts2_sig, Ts4_sig,Cs1,Cs1_6] = MSST(Sig_noise,n)


[Ts1]=MSST_Y(Sig_noise,50,1);
[Ts1_6]=MSST_Y_new(Sig_noise,50,6);

gamma = 10^(-2);
sigma = 0.055;
[~,~,~,~,~,~,Ts2,Ts3,Ts4] = sstn(Sig_noise,gamma,sigma); 
.................................................................
[Cs1] = Ridge_mult_detection_Y(abs(Ts1), 1:2, 2, 1, 5);
[Cs1_6] = Ridge_mult_detection_Y(abs(Ts1_6), 1:2, 2, 1, 5);
[Cs2] = Ridge_mult_detection_Y(abs(Ts2), 1:2, 2, 1, 5);
[Cs4] = Ridge_mult_detection_Y(abs(Ts4), 1:2, 2, 1, 5);

Cs1=sort(Cs1,'descend');
Cs1_6=sort(Cs1_6,'descend');
Cs2=sort(Cs2,'descend');
Cs4=sort(Cs4,'descend');

ds=1;
for k=1:2
for j=1:n
Ts1_sig(k,j)=sum(real(Ts1(max(1,Cs1(k,j)-ds):min(round(n/2),Cs1(k,j)+ds),j)));
Ts1_6_sig(k,j)=sum(real(Ts1_6(max(1,Cs1_6(k,j)-ds):min(round(n/2),Cs1_6(k,j)+ds),j)));

Ts2_sig(k,j)=sum(real(Ts2(max(1,Cs2(k,j)-ds):min(round(n/2),Cs2(k,j)+ds),j)));
Ts4_sig(k,j)=sum(real(Ts4(max(1,Cs4(k,j)-ds):min(round(n/2),Cs4(k,j)+ds),j)));
end
end



end

