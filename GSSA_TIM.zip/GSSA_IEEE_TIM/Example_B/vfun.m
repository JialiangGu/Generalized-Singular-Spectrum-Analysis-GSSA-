function y = vfun(x)






end

