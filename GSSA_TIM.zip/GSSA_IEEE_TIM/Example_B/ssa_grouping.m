function [r1] = ssa_grouping(x,f1,f2,a1,a2,Num,Fs)

band1 = [f1-a1*1.5-0.5 f1+a1*1.5+0.5];
band2 = [f2-a2*1.5-0.5 f2+a2*1.5+0.5];

Nfft = 2048;
Index1 = [];
Index2 = [];
for i = 1:Num
    fft0 = abs(fft(x(i,:), Nfft));
    fft1 = fft0(1:Nfft/2);
    ind = max(find(max(fft1) == fft1))*Fs / Nfft;
    
    if (ind > band1(1,1)) & (ind < band1(1,2))
        Index1 = [Index1 i];
    else if (ind > band2(1,1)) & (ind < band2(1,2))
            Index2 = [Index2 i];
        end
    end
end
        
r1(1,:) = sum(x(Index1,:),1);
r1(2,:) = sum(x(Index2,:),1);
    
   
end

