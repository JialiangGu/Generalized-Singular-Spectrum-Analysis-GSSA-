close all
clc
clear all


% simulated signal
SampFreq = 200;
t = 1/SampFreq : 1/SampFreq : 4;
%------------------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% parameters setting
M = 1;  % repeat M times
Error_SST = zeros(M,2);
Error_SST2 = zeros(M,2);
Error_MSST = zeros(M,2);
Error_GSSA = zeros(M,2);
%--------------------------------------------------

%------------- construct non-stationary signals with different a2(i.e., A)
for a2 = 1:6
f1 = 40;
f2 = 17;
a1 = 1;

S1 = sin(2*pi*(f1*t + a1*sin(1.5*t))); % mode S1
S2 = sin(2*pi*(f2*t + a2*sin(1.5*t))); % mode S2
Sig = S1 + S2;
N = length(Sig);
n=length(Sig);
time=(1:n)/SampFreq;
fre=(SampFreq/2)/(n/2):(SampFreq/2)/(n/2):(SampFreq/2);

% time-varying frequency
IF1=f1 + a1*1.5*cos(1.5*t);
IF2=f2 + a2*1.5*cos(1.5*t);

%%%%%%%%%%%%%%%%%%%%%%%%%%% repeat M times for averaging
for m = 1:M
    m
x = add_noise(Sig', 10); % add noise
    

% MSST
[Ts1_sig, Ts1_6_sig,Ts2_sig, Ts4_sig,Cs1,Cs1_6] = MSST(x,N);
Error_SST(m,1) = mean(abs(Ts1_sig(1,:)-S1)+abs(Ts1_sig(2,:)-S2));
Error_SST(m,2) = norm(Ts1_sig(1,:)-S1,2)+norm(Ts1_sig(2,:)-S2,2);
Error_SST2(m,1) = mean(abs(Ts2_sig(1,:)-S1)+abs(Ts2_sig(2,:)-S2));
Error_SST2(m,2) = norm(Ts2_sig(1,:)-S1,2)+norm(Ts2_sig(2,:)-S2,2);
Error_MSST(m,1) = mean(abs(Ts1_6_sig(1,:)-S1)+abs(Ts1_6_sig(2,:)-S2));
Error_MSST(m,2) = norm(Ts1_6_sig(1,:)-S1,2)+norm(Ts1_6_sig(2,:)-S2,2);


%  GSSA
T = 20; % maximum iteration for AO
L = 51; % embedding dimension
Num = 20;
[Error_GSSA(m,1),Error_GSSA(m,2),W,r2,corr] = GSSA_PGD(x,T,L,SampFreq,N,S1,S2,Num,f1,f2,a1,a2); % GSSA_PGD


end % end iteration

% MSST
Error_SST_C(a2,1) = mean(Error_SST(:,1));
Error_SST_C(a2,2) = mean(Error_SST(:,2));
Error_SST2_C(a2,1) = mean(Error_SST2(:,1));
Error_SST2_C(a2,2) = mean(Error_SST2(:,2));
Error_MSST_C(a2,1) = mean(Error_MSST(:,1));
Error_MSST_C(a2,2) = mean(Error_MSST(:,2));

% GSSA
Error_GSSA_C(a2,1) = mean(Error_GSSA(:,1));
Error_GSSA_C(a2,2) = mean(Error_GSSA(:,2));

end  % end a2

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fig 5
figure;
plot(time,S1,'b-','linewidth',1.5);hold on;plot(time,Ts1_sig(1,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 4 -1.5 1.5]);
xticks([0 1 2 3 4]);yticks([-1 0 1])
set(gca, 'FontSize', 15)
figure;
plot(time,S2,'b-','linewidth',1.5);hold on;plot(time,Ts1_sig(2,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 4 -1.5 1.5]);
xticks([0 1 2 3 4]);yticks([-1 0 1])
set(gca, 'FontSize', 15)
figure;
plot(time,S1,'b-','linewidth',1.5);hold on;plot(time,Ts2_sig(1,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 4 -1.5 1.5]);
xticks([0 1 2 3 4]);yticks([-1 0 1])
set(gca, 'FontSize', 15)
figure;
plot(time,S2,'b-','linewidth',1.5);hold on;plot(time,Ts2_sig(2,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 4 -1.5 1.5]);
xticks([0 1 2 3 4]);yticks([-1 0 1])
set(gca, 'FontSize', 15)
figure;
plot(time,S1,'b-','linewidth',1.5);hold on;plot(time,Ts1_6_sig(1,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 4 -1.5 1.5]);
xticks([0 1 2 3 4]);yticks([-1 0 1])
set(gca, 'FontSize', 15)
figure;
plot(time,S2,'b-','linewidth',1.5);hold on;plot(time,Ts1_6_sig(2,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 4 -1.5 1.5]);
xticks([0 1 2 3 4]);yticks([-1 0 1])
set(gca, 'FontSize', 15)
figure;
plot(time,S1,'b-','linewidth',1.5);hold on;plot(time,r2(1,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 4 -1.5 1.5]);
xticks([0 1 2 3 4]);yticks([-1 0 1])
set(gca, 'FontSize', 15)
figure;
plot(time,S2,'b-','linewidth',1.5);hold on;plot(time,r2(2,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 4 -1.5 1.5]);
xticks([0 1 2 3 4]);yticks([-1 0 1])
set(gca, 'FontSize', 15)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fig 6
figure()
hold on
plot([1 2 3 4 5 6],Error_SST_C(:,1),'mo-','LineWidth',1.5)
plot([1 2 3 4 5 6],Error_SST2_C(:,1),'ko-','LineWidth',1.5)
plot([1 2 3 4 5 6],Error_MSST_C(:,1),'ro-','LineWidth',1.5)
plot([1 2 3 4 5 6],Error_GSSA_C(:,1),'bo-','LineWidth',1.5)
xticks([1 2 3 4 5 6])
xticklabels({'1', '2', '3', '4', '5', '6'})
xlim([1 6])
xlabel('A2')
ylabel('L1-norm Error')
legend('SST','Second-order SST2','MSST','GSSA PGD-AO')
figure()
hold on
plot([1 2 3 4 5 6],Error_SST_C(:,2),'mo-','LineWidth',1.5)
plot([1 2 3 4 5 6],Error_SST2_C(:,2),'ko-','LineWidth',1.5)
plot([1 2 3 4 5 6],Error_MSST_C(:,2),'ro-','LineWidth',1.5)
plot([1 2 3 4 5 6],Error_GSSA_C(:,2),'bo-','LineWidth',1.5)
xticks([1 2 3 4 5 6])
xticklabels({'1', '2', '3', '4', '5', '6'})
xlim([1 6])
xlabel('A2')
ylabel('L2-norm Error')
legend('SST','Second-order SST','MSST','GSSA PGD-AO')



