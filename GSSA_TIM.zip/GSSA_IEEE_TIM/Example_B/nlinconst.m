function [c ceq] = nlinconst(x)




end

