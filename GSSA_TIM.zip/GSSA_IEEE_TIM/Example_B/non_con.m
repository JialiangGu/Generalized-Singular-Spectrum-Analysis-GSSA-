function [c,ceq] = non_con(u)

c = [];
%u*u'
ceq = u*u' - 1;

end

