clear all;
clc;
close all;

% simulated signal
T=10;
L=101; % embedding dimension
Fs = 200;
f1=2; % mode 1: 2Hz
Duration = 5;
N=2*Fs * Duration;
t1 = [1/Fs:1/Fs:Duration];
y1=1*[sin(2*pi*f1.*t1) zeros(1,Fs*Duration)];
frequency=[5 7 9]; % mode 2: f2
amplitude = [0.5 0.6 0.7 0.8 0.9 1]; % H
Iteration = 1; % repeat 100 times for averaging
%---------------------------------------------------

% L2 norm maximization
L2_error_SSA = zeros(length(amplitude),length(frequency));
L1_error_SSA = zeros(length(amplitude),length(frequency));
% L1 norm hankelization
L2_error_L1SSA = zeros(length(amplitude),length(frequency));
L1_error_L1SSA = zeros(length(amplitude),length(frequency));
% L1 norm maximization
L2_error_PCA_L1SSA = zeros(length(amplitude),length(frequency));
L1_error_PCA_L1SSA = zeros(length(amplitude),length(frequency));
% GSSA
L2_error_GSSA = zeros(length(amplitude),length(frequency));
L1_error_GSSA = zeros(length(amplitude),length(frequency));

% -----------------construct non-stationary signals with differnt H and f2
Num = 4; % select components for reconstruction
for a = 1:length(amplitude) % H
    a
for f2 = 1:length(frequency) % f2
    f2
    
y2=[zeros(1,Fs*Duration) amplitude(a)*sin(2*pi*frequency(f2).*t1)]; % different mode y2
y=y1+y2; % mode y1 + mode y2
x0=y'; % noise free

for m = 1:Iteration % repeat 100 times for averaging

x=add_noise(x0,10); % add noise of 10dB

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% performance comparison
%------------conventional SSA
[ssa_vector0,U0, Y0, S0] = gssa(x,ones(L,1));
ind = similarity_detection(ssa_vector0,Num);
r0(1,:) = ssa_vector0(1,:)+ssa_vector0(ind,:);
r0(2,:) = sum(ssa_vector0(1:Num,:),1) - r0(1,:);
l2_error_SSA(m,1) = norm(r0(1,:)-y1,2)+norm(r0(2,:)-y2,2);
l1_error_SSA(m,1) = mean(abs(r0(1,:)-y1)+abs(r0(2,:)-y2));

%-----------L1 norm hankelization
[ssa_vector_L1,U_L1, Y_L1, S_L1] = L1_SSA(x, L);
ind = similarity_detection(ssa_vector_L1,Num);
r_L1(1,:) = ssa_vector_L1(1,:)+ssa_vector_L1(ind,:);
r_L1(2,:) = sum(ssa_vector_L1(1:Num,:),1) - r_L1(1,:);
l2_error_L1SSA(m,1) = norm(r_L1(1,:)-y1,2)+norm(r_L1(2,:)-y2,2);
l1_error_L1SSA(m,1) = mean(abs(r_L1(1,:)-y1)+abs(r_L1(2,:)-y2));

%-----------L1 norm maximization
[ssa_vector_PCA_L1,U_PCA_L1,X] = PCA_L1_greedy(x, L);
ind = similarity_detection(ssa_vector_PCA_L1,Num);
r_PCA_L1(1,:) = ssa_vector_PCA_L1(1,:)+ssa_vector_PCA_L1(ind,:);
r_PCA_L1(2,:) = sum(ssa_vector_PCA_L1(1:Num,:),1) - r_PCA_L1(1,:);
l2_error_PCA_L1SSA(m,1) = norm(r_PCA_L1(1,:)-y1,2)+norm(r_PCA_L1(2,:)-y2,2);
l1_error_PCA_L1SSA(m,1) = mean(abs(r_PCA_L1(1,:)-y1)+abs(r_PCA_L1(2,:)-y2));

% GSSA
[l1_error_GSSA(m,1),l2_error_GSSA(m,1),W,r1,corr] = GSSA_PGD(x,T,L,Fs,N,y1,y2,Num);


end % end iteration

L2_error_SSA(a,f2) = sum(l2_error_SSA);
L1_error_SSA(a,f2) = sum(l1_error_SSA);

L2_error_L1SSA(a,f2) = sum(l2_error_L1SSA);
L1_error_L1SSA(a,f2) = sum(l1_error_L1SSA);

L2_error_PCA_L1SSA(a,f2) = sum(l2_error_PCA_L1SSA);
L1_error_PCA_L1SSA(a,f2) = sum(l1_error_PCA_L1SSA);

L2_error_GSSA(a,f2) = sum(l2_error_GSSA);
L1_error_GSSA(a,f2) = sum(l1_error_GSSA);

end % end frequency f2
end % end amplitude H


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% plot figures
% ------------------------ Fig 1
figure()
subplot(2,1,1)
hold on
plot(W(:,1)/max(W(:,1)),'b')
plot(W(:,end-1)/max(W(:,end-1)), 'r')
legend('Rectangular window', 'PGD - AO')
xlabel('Samples')
ylabel('Amplitude')
xlim([0 L])
grid on
subplot(2,1,2)
hold on
fft_x = (10*log10(abs(fft(W(:,1),2048))));
plot([0:Fs/N:Fs/2-Fs/N]./(Fs/2), fft_x(1:N/2)-max(fft_x(1:N/2)), 'b')
fft_x = (10*log10(abs(fft(W(:,end-1),2048))));
plot([0:Fs/N:Fs/2-Fs/N]./(Fs/2), fft_x(1:N/2)-max(fft_x(1:N/2)), 'r')
xlabel('Normalized frequency')
ylabel('Magnitude spectrum(dB)')
legend('Rectangular window', 'PGD - AO')
xlim([0 0.2])
ylim([-40 5])
grid on

% --------------------------- Fig 2
time=(1:N)/Fs;
figure;
plot(time,y1,'b-','linewidth',1.2);hold on;plot(time,r0(1,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 10 -1.2 1.2]);
xticks([0 5 10]);yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
title('Fig2a')
figure;
plot(time,y2,'b-','linewidth',1.2);hold on;plot(time,r0(2,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 10 -1.2 1.2]);
xticks([0 5 10]);yticks([-1 0 1])
set(gca, 'FontSize', 15)
title('Fig2b')
figure;
plot(time,y1,'b-','linewidth',1.2);hold on;plot(time,r_L1(1,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 10 -1.2 1.2]);
xticks([0 5 10]);yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
title('Fig2c')
figure;
plot(time,y2,'b-','linewidth',1.2);hold on;plot(time,r_L1(2,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 10 -1.2 1.2]);
xticks([0 5 10]);yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
title('Fig2d')
figure;
plot(time,y1,'b-','linewidth',1.2);hold on;plot(time,r_PCA_L1(1,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 10 -1.2 1.2]);
xticks([0 5 10]);yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
title('Fig2e')
figure;
plot(time,y2,'b-','linewidth',1.2);hold on;plot(time,r_PCA_L1(2,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 10 -1.2 1.2]);
xticks([0 5 10]);yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
title('Fig2f')
figure;
plot(time,y1,'b-','linewidth',1.2);hold on;plot(time,r1(1,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 10 -1.2 1.2]);
xticks([0 5 10]);yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
title('Fig2g')
figure;
plot(time,y2,'b-','linewidth',1.2);hold on;plot(time,r1(2,:),'r-','linewidth',1);
xlabel('Time');ylabel('Amplitude');axis ([0 10 -1.2 1.2]);
xticks([0 5 10]);yticks([-1 0 1])
grid on
set(gca, 'FontSize', 15)
title('Fig2h')

%----------------------------- Fig 3

%-------------------------------L1 error
figure()
hold on
plot([0.5 0.6 0.7 0.8 0.9 1],L1_error_SSA(:,1),'r*--','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L1_error_L1SSA(:,1),'k^:','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L1_error_PCA_L1SSA(:,1),'g+-.','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L1_error_GSSA(:,1),'bo-','LineWidth',1.5)
xticks([0.5 0.6 0.7 0.8 0.9 1])
xticklabels({'0.5', '0.6', '0.7', '0.8', '0.9', '1'})
yticks([0 0.2 0.4 0.6])
xlim([0.5 1])
xlabel('H')
set(gca, 'FontSize', 15)
ylabel('L1-norm Error')
legend('L2-norm maximization', 'L1-norm hankelization', 'L1-norm maximization', 'GSSA PGD-AO')
grid on
figure()
hold on
plot([0.5 0.6 0.7 0.8 0.9 1],L1_error_SSA(:,2),'r*--','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L1_error_L1SSA(:,2),'k^:','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L1_error_PCA_L1SSA(:,2),'g+-.','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L1_error_GSSA(:,2),'bo-','LineWidth',1.5)
xticks([0.5 0.6 0.7 0.8 0.9 1])
xticklabels({'0.5', '0.6', '0.7', '0.8', '0.9', '1'})
yticks([0 0.2 0.4 0.6])
xlim([0.5 1])
xlabel('H')
set(gca, 'FontSize', 15)
ylabel('L1-norm Error')
legend('L2-norm maximization', 'L1-norm hankelization', 'L1-norm maximization', 'GSSA PGD-AO')
grid on
figure()
hold on
plot([0.5 0.6 0.7 0.8 0.9 1],L1_error_SSA(:,3),'r*--','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L1_error_L1SSA(:,3),'k^:','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L1_error_PCA_L1SSA(:,3),'g+-.','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L1_error_GSSA(:,3),'bo-','LineWidth',1.5)
xticks([0.5 0.6 0.7 0.8 0.9 1])
xticklabels({'0.5', '0.6', '0.7', '0.8', '0.9', '1'})
yticks([0 0.2 0.4 0.6])
xlim([0.5 1])
xlabel('H')
set(gca, 'FontSize', 15)
ylabel('L1-norm Error')
legend('L2-norm maximization', 'L1-norm hankelization', 'L1-norm maximization', 'GSSA PGD-AO')
grid on

%------------------------------------ L2 error
figure()
hold on
plot([0.5 0.6 0.7 0.8 0.9 1],L2_error_SSA(:,1),'r*--','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L2_error_L1SSA(:,1),'k^:','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L2_error_PCA_L1SSA(:,1),'g+-.','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L2_error_GSSA(:,1),'bo-','LineWidth',1.5)
xticks([0.5 0.6 0.7 0.8 0.9 1])
xticklabels({'0.5', '0.6', '0.7', '0.8', '0.9', '1'})
xlim([0.5 1])
xlabel('H')
set(gca, 'FontSize', 15)
ylabel('L2-norm Error')
legend('L2-norm maximization', 'L1-norm hankelization', 'L1-norm maximization', 'GSSA PGD-AO')
grid on
figure()
hold on
plot([0.5 0.6 0.7 0.8 0.9 1],L2_error_SSA(:,2),'r*--','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L2_error_L1SSA(:,2),'k^:','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L2_error_PCA_L1SSA(:,2),'g+-.','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L2_error_GSSA(:,2),'bo-','LineWidth',1.5)
xticks([0.5 0.6 0.7 0.8 0.9 1])
xticklabels({'0.5', '0.6', '0.7', '0.8', '0.9', '1'})
xlim([0.5 1])
xlabel('H')
set(gca, 'FontSize', 15)
ylabel('L2-norm Error')
legend('L2-norm maximization', 'L1-norm hankelization', 'L1-norm maximization', 'GSSA PGD-AO')
grid on
figure()
hold on
plot([0.5 0.6 0.7 0.8 0.9 1],L2_error_SSA(:,3),'r*--','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L2_error_L1SSA(:,3),'k^:','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L2_error_PCA_L1SSA(:,3),'g+-.','LineWidth',1.5)
plot([0.5 0.6 0.7 0.8 0.9 1],L2_error_GSSA(:,3),'bo-','LineWidth',1.5)
xticks([0.5 0.6 0.7 0.8 0.9 1])
xticklabels({'0.5', '0.6', '0.7', '0.8', '0.9', '1'})
xlim([0.5 1])
xlabel('H')
set(gca, 'FontSize', 15)
ylabel('L2-norm Error')
legend('L2-norm maximization', 'L1-norm hankelization', 'L1-norm maximization', 'GSSA PGD-AO')
grid on





