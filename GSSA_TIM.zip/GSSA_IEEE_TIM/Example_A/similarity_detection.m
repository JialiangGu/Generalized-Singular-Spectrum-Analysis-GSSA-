function [ind] = similarity_detection(component,r)

corr_vector = component(1,:) * component(2:r,:)';
ind = find(corr_vector == max(corr_vector))+1;

end

