function [Frec] = L1_Hankelization(Xp, L, K)

Xp_fli = fliplr(Xp); 
for k = -(L-1):K-1
    d = [];
    d = diag(Xp_fli,k);  % anti-diagonal elements
    %Frec(1,L+k) = mean(d); % conventional averaging method
    Frec(1,L+k) = median(d); % median method : L1 SSA
    
end

Frec = fliplr(Frec);
    

end

