function [maxsidelobe] = MaxSidelobe(u)

Nfft = 4096;
fft_u=20*log10(abs(fft(u,Nfft)));
localmax_index=islocalmax(fft_u(1:Nfft/2));
if max(fft_u(1:Nfft/2)) == fft_u(1,1)
    localmax_index(1,1) = 1;
end

fft_u(1:Nfft/2) = fft_u(1:Nfft/2) + abs(min(fft_u(1:Nfft/2)));
local_maximum=sort(fft_u(1:Nfft/2) .* localmax_index, 'descend');
maxsidelobe=local_maximum(2,1) - local_maximum(1,1);
end

