clear;
clc;
close all;

% loading data
load('EEG_open.mat')
Fs = 174;
N=4000;
L = 101;  % embedding dimension

%----------------------------------- define window function
order_list = [0 0.2 0.4 0.6 0.8 1]; % \alpha value
k=[0:1:L+1];
window = cos((pi*k(2:end-1))/(L+1) - pi/2)'; 
for i = 1:length(order_list)
    g_window(:, i) = window .^ order_list(i); % family of cosine window
end

%------apply different window function to SSA 
for i = 1:length(order_list)
    i
    [ssa_vector(:, :, i), U(:, :, i), D(:, i),S(:,:,i)] = gssa(x, g_window(:, i));
end
%-------------------------------------------------------------------------


% ------------------------------------------------figure 1
figure()
subplot(2,1,1)
hold on
plot(window.^0, 'b')
plot(window.^0.5, 'r--')
plot(window.^2, 'k-.')
legend('\alpha=0', '\alpha=0.5','\alpha=2')
xlabel('Samples')
ylabel('Amplitude')
xlim([0 L])
title('Window functions of different non-negative real number \alpha')
grid on
Nfft = 512;
subplot(2,1,2)
hold on
fft_x=20*log10((abs(fft(window.^0, Nfft))));
plot([0:174/Nfft:87-174/Nfft]./87, fft_x(1:Nfft/2)-max(fft_x(1:Nfft/2)), 'b')
fft_x=20*log10((abs(fft(window.^0.5, Nfft))));
plot([0:174/Nfft:87-174/Nfft]./87, fft_x(1:Nfft/2)-max(fft_x(1:Nfft/2)), 'r--')
fft_x=20*log10((abs(fft(window.^2, Nfft))));
plot([0:174/Nfft:87-174/Nfft]./87, fft_x(1:Nfft/2)-max(fft_x(1:Nfft/2)), 'k-.')
title('Window functions in frequency domain')
xlabel('Normalized frequency')
ylabel('Power spectrum(dB)')
legend('\alpha=0', '\alpha=0.5','\alpha=2')
xlim([0 0.5])
ylim([-100 5])
grid on

% --------------------------------------------------figure 2
figure()
xcor=xcorr(x(1:4000,1), x(1:3000,1));
subplot(3,1,1)
plot(x(1:4000,1))
xlabel('Samples')
ylabel('Amplitude')
title('An EEG signal')
grid on
subplot(3,1,2)
plot(-3999:3999,xcor)
xlabel('Lags')
ylabel('Correlation values')
title('Autocorrelation function')
grid on
subplot(3,1,3)
full=(abs(fft(xcor)));
plot([174/8000:174/8000:87],full(1:4000))
xlabel('Frequency')
xlim([0 30])
ylabel('Power spectrum(dB)')
title('Power spectral density')
grid on

% -----------------------------------------------figure 3
figure()
full=(abs(fft(xcor))).^2;
semilogy([174/8000:174/8000:87],full(1:4000), 'r')
xlim([0 87])
ylim([10^3 10^18])
hold on
sub_rect=(abs(fft(xcor(4000:4999,1),7999))).^2;
semilogy([174/8000:174/8000:87],sub_rect(1:4000), 'b--')
xlim([0 87])
ylim([10^3 10^18])
hold on
sub_hamming=(abs(fft(xcor(4000:4999,1).*hamming(1000),7999))).^2;
semilogy([174/8000:174/8000:87],sub_hamming(1:4000), 'k-.')
xlim([0 87])
ylim([10^3 10^18])
hold on
xlabel('Frequency')
ylabel('Power spectrum')
legend('true S(f)', 'apply rectangular window', 'apply hamming window')
grid on


% --------------------------------------------------figure 4
figure()
surf(window.^0*window.^0')
xlabel('Samples')
ylabel('Samples')
zlabel('Amplitude')
zlim([0.8 1.2])
xlim([0 81])
ylim([0 81])
title('\alpha=0')
figure()
surf(window.^0.5*window.^0.5')
xlabel('Samples')
ylabel('Samples')
zlabel('Amplitude')
xlim([0 81])
ylim([0 81])
title('\alpha=0.5')
figure()
surf(window.^2*window.^2')
xlabel('Samples')
ylabel('Samples')
zlabel('Amplitude')
title('\alpha=2')
xlim([0 81])
ylim([0 81])

% -----------------------------------------------figure 5
figure()
fft_2 = (abs(fftshift(fft2(S(:,:,1), 512, 512))));
mesh(fft_2 ./ max(max(fft_2)))
xlabel('Samples')
ylabel('Samples')
zlabel('Normalized magnitude')
title('Rectangular window (512 points FFT)')
xlim([0 512])
ylim([0 512])
[ssa_vector1, U1, D1,S1] = gssa(x, window.^2);
figure()
fft_2 = (abs(fftshift(fft2(S1, 512, 512))));
mesh(fft_2 ./ max(max(fft_2)))
xlabel('Samples')
ylabel('Samples')
zlabel('Normalized magnitude')
title('Hanning window (512 points FFT)')
xlim([0 512])
ylim([0 512])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure 6  alpha=0:0.02:1
load('U60.mat')
load('U100.mat')
figure()
subplot(2,1,1)
ind = 1;
for i = 1:51
    %ENBW(i,1) = EnBW(U60(:,ind,i));
    MSLL(i,1) = MaxSidelobe(U60(:,ind,i));

    %ENBW(i,2) = EnBW(U100(:,ind,i));
    MSLL(i,2) = MaxSidelobe(U100(:,ind,i));
end
hold on
plot(0:0.02:1,MSLL(:,1), 'b')
plot(0:0.02:1,MSLL(:,2), 'r--')
xlabel('\alpha')
ylabel('MSLL')
xlim([0 1])
xticklabels({'0','0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8','0.9','1'})
title('Maximum side love level (the second eigenfilter)')
legend('L=61', 'L=101')
grid on
subplot(2,1,2)
ind = 2;
for i = 1:51
    %ENBW(i,1) = EnBW(U60(:,ind,i));
    MSLL(i,1) = MaxSidelobe(U60(:,ind,i));

    %ENBW(i,2) = EnBW(U100(:,ind,i));
    MSLL(i,2) = MaxSidelobe(U100(:,ind,i));
end
hold on
plot(0:0.02:1,MSLL(:,1), 'b')
plot(0:0.02:1,MSLL(:,2), 'r--')
xlabel('\alpha')
ylabel('MSLL')
xlim([0 1])
xticklabels({'0','0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8','0.9','1'})
title('Maximum side love level (the second eigenfilter)')
legend('L=61', 'L=101')
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% end Figure 6


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Figure 8 
%original signal
figure()
subplot(2,1,1)
plot(x,'b')
title('Original signal(eyes open)')
ylabel('Amplitude')
xlabel('Samples')
xlim([1 4000])
grid on
subplot(2,1,2)
pmtm(x,2.5)  % multitaper spectral estimation

% --------------------  The first 5 SSA components
figure()
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U(:, 1, 1), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 1, 2), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 1, 3), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2),'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 1, 6), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on
figure()
hold on
fft_x=20*log10((abs(fft(ssa_vector(1, :, 1), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(1, :, 2), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(1, :, 3), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(1, :, 6), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on

figure()
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U(:, 2, 1), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 2, 2), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 2, 3), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 2, 6), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on
figure()
hold on
fft_x=20*log10((abs(fft(ssa_vector(2, :, 1), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(2, :, 2), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(2, :, 3), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(2, :, 6), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on

figure()
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U(:, 3, 1), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 3, 2), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 3, 3), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 3, 6), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on
figure()
hold on
fft_x=20*log10((abs(fft(ssa_vector(3, :, 1), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(3, :, 2), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(3, :, 3), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(3, :, 6), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on

figure()
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U(:, 4, 1), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 4, 2), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 4, 3), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 4, 6), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on
figure()
hold on
fft_x=20*log10((abs(fft(ssa_vector(4, :, 1), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(4, :, 2), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(4, :, 3), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(4, :, 6), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on

figure()
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U(:, 5, 1), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 5, 2), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 5, 3), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 5, 6), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on
figure()
hold on
fft_x=20*log10((abs(fft(ssa_vector(5, :, 1), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(5, :, 2), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(5, :, 3), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(5, :, 6), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% End Figure 8


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Figure 11
L = 51;  % window length
k=[0:1:L+1];
window = cos((pi*k(2:end-1))/(L+1) - pi/2)'; 
[ssa_vector0, U0, D0,S0] = gssa(x, window.^(0)); % SSA
[ssa_vector1, U1, D1, S1] = gssa(x, window.^(0.2)); % GSSA

figure()
subplot(1,2,1)
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U0(:, 1), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'r')
fft_x=20*log10((abs(fft(U1(:, 1), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'b')
title('PSD of eigenfilter 1')
xlabel('Frequency')
ylabel('Power Spectral Density(dB)')
legend('Xu et al. (2018)', 'GSSA (\alpha=0.2)')
xlim([0 50])
grid on
subplot(1,2,2)
hold on
fft_x=20*log10((abs(fft(ssa_vector0(1, :), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'r')
fft_x=20*log10((abs(fft(ssa_vector1(1, :), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'b')
title('PSD of RC 1')
xlabel('Frequency')
ylabel('Power Spectral Density(dB)')
legend('Xu et al. (2018)', 'GSSA (\alpha=0.2)')
xlim([0 50])
grid on

figure()
subplot(1,2,1)
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U0(:, 2), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'r')
fft_x=20*log10((abs(fft(U1(:, 2), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'b')
title('PSD of eigenfilter 2')
xlabel('Frequency')
ylabel('Power Spectral Density(dB)')
legend('Xu et al. (2018)', 'GSSA (\alpha=0.2)')
xlim([0 50])
grid on
subplot(1,2,2)
hold on
fft_x=20*log10((abs(fft(ssa_vector0(2, :), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'r')
fft_x=20*log10((abs(fft(ssa_vector1(2, :), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'b')
title('PSD of RC 2')
xlabel('Frequency')
ylabel('Power Spectral Density(dB)')
legend('Xu et al. (2018)', 'GSSA (\alpha=0.2)')
xlim([0 50])
grid on

figure()
subplot(1,2,1)
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U0(:, 3), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'r')
fft_x=20*log10((abs(fft(U1(:, 3), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'b')
title('PSD of eigenfilter 3')
xlabel('Frequency')
ylabel('Power Spectral Density(dB)')
legend('Xu et al. (2018)', 'GSSA (\alpha=0.2)')
xlim([0 50])
grid on
subplot(1,2,2)
hold on
fft_x=20*log10((abs(fft(ssa_vector0(3, :), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'r')
fft_x=20*log10((abs(fft(ssa_vector1(3, :), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'b')
title('PSD of RC 3')
xlabel('Frequency')
ylabel('Power Spectral Density(dB)')
legend('Xu et al. (2018)', 'GSSA (\alpha=0.2)')
xlim([0 50])
grid on

figure()
subplot(1,2,1)
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U0(:, 4), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'r')
fft_x=20*log10((abs(fft(U1(:, 4), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'b')
title('PSD of eigenfilter 4')
xlabel('Frequency')
ylabel('Power Spectral Density(dB)')
legend('Xu et al. (2018)', 'GSSA (\alpha=0.2)')
xlim([0 50])
grid on
subplot(1,2,2)
hold on
fft_x=20*log10((abs(fft(ssa_vector0(4, :), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'r')
fft_x=20*log10((abs(fft(ssa_vector1(4, :), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'b')
title('PSD of RC 4')
xlabel('Frequency')
ylabel('Power Spectral Density(dB)')
legend('Xu et al. (2018)', 'GSSA (\alpha=0.2)')
xlim([0 50])
grid on

figure()
subplot(1,2,1)
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U0(:, 5), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'r')
fft_x=20*log10((abs(fft(U1(:, 5), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'b')
title('PSD of eigenfilter 5')
xlabel('Frequency')
ylabel('Power Spectral Density(dB)')
legend('Xu et al. (2018)', 'GSSA (\alpha=0.2)')
xlim([0 50])
grid on
subplot(1,2,2)
hold on
fft_x=20*log10((abs(fft(ssa_vector0(5, :), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'r')
fft_x=20*log10((abs(fft(ssa_vector1(5, :), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'b')
title('PSD of RC 5')
xlabel('Frequency')
ylabel('Power Spectral Density(dB)')
legend('Xu et al. (2018)', 'GSSA (\alpha=0.2)')
xlim([0 50])
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% end figure 11


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Table 1,2: grouped spectral entropy
Nfft=1024;
for i = 1:length(order_list)
for j=1:L
	% eigenvalue U
	fft_x=0;
	fft_x = (abs(fft(U(:, j, i), Nfft))).^2;  % power spectrum
	energy_ratio(j,1)=sum(fft_x(1:2))/(sum(fft_x(1:Nfft/2))); %drift
	energy_ratio(j,2)=sum(fft_x(3:23))/(sum(fft_x(1:Nfft/2))); %delta wave
	energy_ratio(j,3)=sum(fft_x(24:45))/(sum(fft_x(1:Nfft/2))); %theta wave
	energy_ratio(j,4)=sum(fft_x(46:80))/(sum(fft_x(1:Nfft/2)));  % alpha wave
	energy_ratio(j,5)=sum(fft_x(81:175))/(sum(fft_x(1:Nfft/2)));  % beta wave
	energy_ratio(j,6)=sum(fft_x(176:290))/(sum(fft_x(1:Nfft/2)));  % gamma wave
	energy_ratio(j,7)=sum(fft_x(291:512))/(sum(fft_x(1:Nfft/2))); % noise
	U_GSE(j, i)=-energy_ratio(j,:)*log2(energy_ratio(j,:)');
	% SSA component
	fft_x=0;
	fft_x = (abs(fft(ssa_vector(j,:,i), N))).^2;  % power spectrum
	ssa_energy_ratio(j,1)=sum(fft_x(1:10))/(sum(fft_x(1:N/2))); %drift
	ssa_energy_ratio(j,2)=sum(fft_x(11:100))/(sum(fft_x(1:N/2))); %delta wave
	ssa_energy_ratio(j,3)=sum(fft_x(101:180))/(sum(fft_x(1:N/2))); %theta wave
	ssa_energy_ratio(j,4)=sum(fft_x(181:300))/(sum(fft_x(1:N/2)));  % alpha wave
	ssa_energy_ratio(j,5)=sum(fft_x(301:700))/(sum(fft_x(1:N/2)));  % beta wave
	ssa_energy_ratio(j,6)=sum(fft_x(701:1150))/(sum(fft_x(1:N/2)));  % gamma wave
	ssa_energy_ratio(j,7)=sum(fft_x(1151:2000))/(sum(fft_x(1:N/2))); % noise    
	ssa_GSE(j, i)=-ssa_energy_ratio(j,:)*log2(ssa_energy_ratio(j,:)');
end

end % end order_list


