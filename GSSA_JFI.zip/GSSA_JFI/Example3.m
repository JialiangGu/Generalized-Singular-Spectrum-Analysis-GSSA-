clear;
clc;
close all;

% loading data
load('EEG_closed.mat')
Fs = 174;
N=4000;
L = 101;  % embedding dimension

%----------------------------------- define window function
order_list = [0 0.2 0.4 0.6 0.8 1]; % \alpha value
k=[0:1:L+1];
window = cos((pi*k(2:end-1))/(L+1) - pi/2)'; 
for i = 1:length(order_list)
    g_window(:, i) = window .^ order_list(i); % family of cosine window
end

%------apply different window function to SSA 
for i = 1:length(order_list)
    i
    [ssa_vector(:, :, i), U(:, :, i), D(:, i),S(:,:,i)] = gssa(x, g_window(:, i));
end
%-------------------------------------------------------------------------


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Figure 10
%original signal
figure()
subplot(2,1,1)
plot(x,'b')
title('Original signal(eyes open)')
ylabel('Amplitude')
xlabel('Samples')
xlim([1 4000])
grid on
subplot(2,1,2)
pmtm(x,2.5)  % multitaper spectral estimation

% --------------------  The first 5 SSA components
figure()
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U(:, 1, 1), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 1, 2), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 1, 3), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2),'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 1, 6), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on
figure()
hold on
fft_x=20*log10((abs(fft(ssa_vector(1, :, 1), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(1, :, 2), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(1, :, 3), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(1, :, 6), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on

figure()
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U(:, 2, 1), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 2, 2), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 2, 3), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 2, 6), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on
figure()
hold on
fft_x=20*log10((abs(fft(ssa_vector(2, :, 1), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(2, :, 2), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(2, :, 3), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(2, :, 6), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on

figure()
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U(:, 3, 1), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 3, 2), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 3, 3), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 3, 6), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on
figure()
hold on
fft_x=20*log10((abs(fft(ssa_vector(3, :, 1), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(3, :, 2), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(3, :, 3), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(3, :, 6), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on

figure()
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U(:, 4, 1), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 4, 2), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 4, 3), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 4, 6), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on
figure()
hold on
fft_x=20*log10((abs(fft(ssa_vector(4, :, 1), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(4, :, 2), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(4, :, 3), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(4, :, 6), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on

figure()
Nfft=1024;
hold on
fft_x=20*log10((abs(fft(U(:, 5, 1), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 5, 2), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 5, 3), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(U(:, 5, 6), Nfft))));
plot(174/Nfft:174/Nfft:87,fft_x(1:Nfft/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on
figure()
hold on
fft_x=20*log10((abs(fft(ssa_vector(5, :, 1), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','r','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(5, :, 2), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','b','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(5, :, 3), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','k','LineWidth',0.8)
fft_x=20*log10((abs(fft(ssa_vector(5, :, 6), N))));
plot(174/N:174/N:87,fft_x(1:N/2), 'Color','#77AC30','LineWidth',0.8)
xlabel('Frequency(Hz)')
ylabel('Power Spectral Density(dB)')
legend('\alpha=0', '\alpha=0.2','\alpha=0.4','\alpha=1','FontSize',12)
xlim([0 35])
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% End Figure 8


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Table 5,6 : grouped spectral entropy
Nfft=1024;
for i = 1:length(order_list)
for j=1:L
	% eigenvalue U
	fft_x=0;
	fft_x = (abs(fft(U(:, j, i), Nfft))).^2;  % power spectrum
	energy_ratio(j,1)=sum(fft_x(1:2))/(sum(fft_x(1:Nfft/2))); %drift
	energy_ratio(j,2)=sum(fft_x(3:23))/(sum(fft_x(1:Nfft/2))); %delta wave
	energy_ratio(j,3)=sum(fft_x(24:45))/(sum(fft_x(1:Nfft/2))); %theta wave
	energy_ratio(j,4)=sum(fft_x(46:80))/(sum(fft_x(1:Nfft/2)));  % alpha wave
	energy_ratio(j,5)=sum(fft_x(81:175))/(sum(fft_x(1:Nfft/2)));  % beta wave
	energy_ratio(j,6)=sum(fft_x(176:290))/(sum(fft_x(1:Nfft/2)));  % gamma wave
	energy_ratio(j,7)=sum(fft_x(291:512))/(sum(fft_x(1:Nfft/2))); % noise
	U_GSE(j, i)=-energy_ratio(j,:)*log2(energy_ratio(j,:)');
	% SSA component
	fft_x=0;
	fft_x = (abs(fft(ssa_vector(j,:,i), N))).^2;  % power spectrum
	ssa_energy_ratio(j,1)=sum(fft_x(1:10))/(sum(fft_x(1:N/2))); %drift
	ssa_energy_ratio(j,2)=sum(fft_x(11:100))/(sum(fft_x(1:N/2))); %delta wave
	ssa_energy_ratio(j,3)=sum(fft_x(101:180))/(sum(fft_x(1:N/2))); %theta wave
	ssa_energy_ratio(j,4)=sum(fft_x(181:300))/(sum(fft_x(1:N/2)));  % alpha wave
	ssa_energy_ratio(j,5)=sum(fft_x(301:700))/(sum(fft_x(1:N/2)));  % beta wave
	ssa_energy_ratio(j,6)=sum(fft_x(701:1150))/(sum(fft_x(1:N/2)));  % gamma wave
	ssa_energy_ratio(j,7)=sum(fft_x(1151:2000))/(sum(fft_x(1:N/2))); % noise    
	ssa_GSE(j, i)=-ssa_energy_ratio(j,:)*log2(ssa_energy_ratio(j,:)');
end

end % end order_list


