function [noisy_signal] = add_noise(x0,Snr)

sigpower=mean(x0.^2);%
noisepower=sigpower/(10^(Snr/10));
noisesignal=randn(length(x0), 1)*sqrt(noisepower);
noisy_signal = x0+noisesignal;

end

