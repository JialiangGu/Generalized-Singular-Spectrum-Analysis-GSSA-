clear all;
close all;
clc

% simulated signal
f1=2;
f2=8;
Fs = 500;
t=1/Fs:1/Fs:2;
y1=1*sin(2*pi*f1.*t);
y2=0.6*sin(2*pi*f2.*t);
y=[y1 y2];
N=length(y);
x = add_noise(y',10); % add white noise of 10dB
L=101; % embedding dimension

%----------------------------------- define window function
order_list = [0:0.1:1]; % \alpha value
k=[0:1:L+1];
window = cos((pi*k(2:end-1))/(L+1) - pi/2)'; 
for i = 1:length(order_list)
    g_window(:, i) = window .^ order_list(i); % family of cosine window
end

%------apply different window function to SSA 
for i = 1:length(order_list)
    [ssa_vector(:, :, i), U(:, :, i), D(:, i), S(:,:,i)] = gssa(x, g_window(:, i));
end
%-------------------------------------------------------------------------


% ----------------------  Figure 7
figure
subplot(4,1,1)
hold on
plot(ssa_vector(1, :, 1)+ssa_vector(2, :, 1),'r')
plot([y1 zeros(1,1000)], 'b')
ylabel('Amplitude')
legend('GSSA component (\alpha=0)','Pure component')
grid on
subplot(4,1,2)
hold on
plot(ssa_vector(1, :, 2)+ssa_vector(2, :, 2),'r')
plot([y1 zeros(1,1000)], 'b')
ylabel('Amplitude')
legend('GSSA component (\alpha=0.2)','Pure component')
grid on
subplot(4,1,3)
hold on
plot(ssa_vector(1, :, 3)+ssa_vector(2, :, 3),'r')
plot([y1 zeros(1,1000)], 'b')
legend('GSSA component (\alpha=0.4)','Pure component')
ylabel('Amplitude')
grid on
subplot(4,1,4)
hold on
plot(ssa_vector(1, :, 4)+ssa_vector(2, :, 4),'r')
plot([y1 zeros(1,1000)], 'b')
legend('GSSA component (\alpha=1)','Pure component')
ylabel('Amplitude')
xlabel('samples')
grid on

figure
subplot(4,1,1)
hold on
plot(ssa_vector(4, :, 1)+ssa_vector(3, :, 1),'r')
plot([zeros(1,1000) y2], 'b')
legend('GSSA component (\alpha=0)','Pure component')
ylabel('Amplitude')
ylim([-0.6 0.6])
grid on
subplot(4,1,2)
hold on
plot(ssa_vector(4, :, 2)+ssa_vector(3, :, 2),'r')
plot([zeros(1,1000) y2], 'b')
legend('GSSA component (\alpha=0.2)','Pure component')
ylabel('Amplitude')
ylim([-0.65 0.65])
grid on
subplot(4,1,3)
hold on
plot(ssa_vector(4, :, 3)+ssa_vector(3, :, 3),'r')
plot([zeros(1,1000) y2], 'b')
legend('GSSA component (\alpha=0.4)','Pure component')
ylabel('Amplitude')
ylim([-0.8 0.8])
grid on
subplot(4,1,4)
hold on
plot(ssa_vector(4, :, 4)+ssa_vector(3, :, 4),'r')
plot([zeros(1,1000) y2], 'b')
legend('GSSA component (\alpha=1)','Pure component')
ylabel('Amplitude')
ylim([-0.8 0.8])
xlabel('samples')
grid on

